library("testthat")

test_check("MSGARCH")
